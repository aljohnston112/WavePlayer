package com.example.waveplayer;

import android.content.BroadcastReceiver;

abstract public class BroadcastReceiverOnServiceConnected extends BroadcastReceiver { }
